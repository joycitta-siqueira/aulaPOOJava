/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dados;

import com.mycompany.database.EntidadeBase;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Joyce
 */
@Entity
@Table(name = "aluno")
@NamedQueries({
    @NamedQuery(name = "Aluno.findAll", query = "SELECT a FROM Aluno a")})
public class Aluno implements Serializable, EntidadeBase {//incluir EntidadeBase para conectar ao hibernate

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "nome")
    private String nome;
    @Column(name = "login")
    private String login;
    @Column(name = "senha")
    private String senha;
    @Column(name = "estadocivil")
    private String estadocivil;
    @Column(name = "sexo")
    private String sexo;
    @Column(name = "interessejava")
    private String interessejava;
    @Column(name = "interessephp")
    private String interessephp;
    @Column(name = "interessepython")
    private String interessepython;
    @Column(name = "telefoneddd")
    private String telefoneddd;
    @Column(name = "telefonenumero")
    private String telefonenumero;
    @Column(name = "telefonetipo")
    private String telefonetipo;

    public Aluno() {
    }

    public Aluno(Integer id) {
        this.id = id;
    }

    public Aluno(Integer id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEstadocivil() {
        return estadocivil;
    }

    public void setEstadocivil(String estadocivil) {
        this.estadocivil = estadocivil;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getInteressejava() {
        return interessejava;
    }

    public void setInteressejava(String interessejava) {
        this.interessejava = interessejava;
    }

    public String getInteressephp() {
        return interessephp;
    }

    public void setInteressephp(String interessephp) {
        this.interessephp = interessephp;
    }

    public String getInteressepython() {
        return interessepython;
    }

    public void setInteressepython(String interessepython) {
        this.interessepython = interessepython;
    }

    public String getTelefoneddd() {
        return telefoneddd;
    }

    public void setTelefoneddd(String telefoneddd) {
        this.telefoneddd = telefoneddd;
    }

    public String getTelefonenumero() {
        return telefonenumero;
    }

    public void setTelefonenumero(String telefonenumero) {
        this.telefonenumero = telefonenumero;
    }

    public String getTelefonetipo() {
        return telefonetipo;
    }

    public void setTelefonetipo(String telefonetipo) {
        this.telefonetipo = telefonetipo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Aluno)) {
            return false;
        }
        Aluno other = (Aluno) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.dados.Aluno[ id=" + id + " ]";
    }

    public void setSenha(char[] password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
