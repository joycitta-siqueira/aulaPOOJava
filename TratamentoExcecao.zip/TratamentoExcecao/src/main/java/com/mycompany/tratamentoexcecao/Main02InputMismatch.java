//EXEMPLO DO TRATAMENTO DA EXCEÇÃO InputMismatchException
package com.mycompany.tratamentoexcecao;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main02InputMismatch {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a;
        int b;
        int op = 0;
        System.out.println("Digite o valor de a");
        try{
        a = scan.nextInt();
        b = a + 1; //Digite um valor muito grande, que não caiba dentro do int - https://pt.wikibooks.org/wiki/Java/Tipos_de_dados_prim%C3%A1rios
        System.out.println(b);
        } catch (InputMismatchException e){
            System.out.println("Você inseriu um valor maior do que o aceitável! Erro: " + e.toString());  
        }

    }
}
