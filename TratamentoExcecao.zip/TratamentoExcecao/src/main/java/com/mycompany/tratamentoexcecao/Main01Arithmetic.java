    /*
    TRATAMENTO DE EXCEÇÃo
    As exceções referem-se aos erros que podem ser gerados durante a execução de um programa. 
    Como o nome sugere, trata-se de algo que interrompe a execucão normal do programa. 
    Em Java há duas categorias: Unchecked (não verificadas) e Checked (verificadas).
    Unchecked: o compilador não verifica o código-fonte para determinar a exceção.
    Checked: o compilador verifica o código-fonte para determinar a exceção. Se uma exceção 
    não for tratada, o compilador acusa a exceção e finaliza o código. Há duas maneiras de tratar exceção, 
    por meio da estrutura try-catch-finally ou cláusuras throws.
    
    Estrutura try-catch-finally: tem a função de desviar a execução do programa caso ocorram certos de tipos 
    de erros de execução, entitulados exceções. 
    
    try {
        trecho do código que pode gerar exceção
    } catch (ClasseExceção1 objeto) {
        tratamento da exceção 1
    } catch (ClasseExceção2 objeto){
        tratamento da exceção 2
    } finnaly {
        trecho que será executado sempre (opcional)
        obs.: será chamado mesmo que no try exista o comando “return”.
    }
    
    Fonte: Biblioteca Digital UCB
    FURGERI, Sérgio. Java 8, ensino didático desenvolvimento e implementação de aplicações. 
    */
    
//EXEMPLO DO TRATAMENTO DA EXCEÇÃO ArithmeticException
package com.mycompany.tratamentoexcecao;
import java.util.Scanner;
public class Main01Arithmetic {

    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        int a;
        int b;
        int c;
        
        try{ //tente executar o código
        System.out.println("Digite a");
        a = scan.nextInt();
        System.out.println("Digite b");
        b = scan.nextInt();
        c = a / b;
        System.out.println(c); 
        } catch(ArithmeticException e){ //caso a exceção ArithmeticException apareça, execute o catch
            System.out.println("Impossível dividir por zero! Erro: " + e.toString()); //toString: apresenta o tipo da exceção e a mensagem de erro
        } finally{
            System.out.println("Final da execução.");
        }
                
        System.out.println("MAIS CÓDIGO");
        System.out.println("MAIS CÓDIGO");
        System.out.println("MAIS CÓDIGO");
    }
    
}
