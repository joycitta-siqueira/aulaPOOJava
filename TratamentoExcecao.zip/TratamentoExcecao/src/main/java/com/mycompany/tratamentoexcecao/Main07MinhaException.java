
package com.mycompany.tratamentoexcecao;


public class Main07MinhaException {

    public static void main(String[] args) throws Exception {
        int[] numerador = {4, 8, 5, 16, 32, 21, 64, 128};
        int[] denominador = {2, 0, 4, 8, 0, 2};

        for (int i = 0; i < numerador.length; i++) {
            try{
            if(numerador[i]%2!=0){
                throw new Classe07DivisaoNaoExata(numerador[i]);//throw força a chamada de uma exceção
            }
            System.out.println("Resultado " + numerador[i]/denominador[i]);
            }catch(ArithmeticException | Classe07DivisaoNaoExata | ArrayIndexOutOfBoundsException e){
                System.out.println("Ocorreu um erro: " + e.toString());
                
            }
        }
    }
    
}
