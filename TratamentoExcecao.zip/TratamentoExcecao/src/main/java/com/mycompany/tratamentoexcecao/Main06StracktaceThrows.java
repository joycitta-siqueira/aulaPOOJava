package com.mycompany.tratamentoexcecao;

public class Main06StracktaceThrows {

    public static void main(String[] args) {
        int[] numerador = {4, 8, 16, 32, 64, 128};
        int[] denominador = {2, 0, 4, 8, 0};

        for (int i = 0; i < numerador.length; i++) {
            try {
                System.out.println("Resultado " + numerador[i] / denominador[i]);
            } catch (Exception e) {
                System.out.println(e.getMessage());//mostrar o erro na tela
                e.printStackTrace(); //mostra as mensagens de erro e informações de compilação
            }

        }
    }
}
