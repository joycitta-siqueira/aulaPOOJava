//EXEMPLO DE TRATAMENTO DE EXCEÇÃO NullPointerExeception
package com.mycompany.tratamentoexcecao;


public class Main03NullPointer {
    public static void main(String[] args) {
    
        String frase = null;
        String novaFrase;
        try{
        novaFrase = frase.toUpperCase(); //tentar realizar alguma ação com a string vazia
        System.out.println("Frase antiga: " + frase);
        System.out.println("Frase nova: " + novaFrase);
        } catch(NullPointerException e){
            System.out.println("String vazia! " + e.toString());
        }
    }
    
}
