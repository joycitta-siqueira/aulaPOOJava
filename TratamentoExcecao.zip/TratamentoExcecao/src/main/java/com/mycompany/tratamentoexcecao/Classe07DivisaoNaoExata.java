
package com.mycompany.tratamentoexcecao;

public class Classe07DivisaoNaoExata extends Exception {
    
    int numerador;
  
    public Classe07DivisaoNaoExata(int numerador) {
        super();
        this.numerador = numerador;
    }
    
    @Override
    public String toString(){
        return "DivisaoNaoExata: Numerador não é um inteiro";
    }
    
    
    
}
