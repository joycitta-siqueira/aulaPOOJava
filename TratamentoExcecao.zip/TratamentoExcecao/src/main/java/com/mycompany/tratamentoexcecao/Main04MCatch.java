package com.mycompany.tratamentoexcecao;

public class Main04MCatch {

    public static void main(String[] args) {
        int[] numerador = {4, 8, 16, 32, 64, 128};
        int[] denominador = {2, 0, 4, 8, 0};

        for (int i = 0; i < numerador.length; i++) {
            try {
                System.out.println("Resultado " + numerador[i] / denominador[i]);
            } catch (ArithmeticException e) {
                System.out.println("Erro ao dividir por zero!");
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Tentou dividir por valor inexistente!");
            } finally {
                System.out.println("Executa independente do try");
            }
        }

    }
    /*SEGUNDA FORMA DE SE FAZER
        for (int i = 0; i < numerador.length; i++) {
            try {
                System.out.println("Resultado " + numerador[i] / denominador[i]);
            } catch (ArithmeticException | ArrayIndexOutOfBoundsException e) {
                System.out.println("Erro ao dividir!");
            }

        }
     */
}
