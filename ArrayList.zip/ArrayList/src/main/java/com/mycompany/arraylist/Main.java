
package com.mycompany.arraylist;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
       //instanciação dos Scanner, o segundo específico para as Strings, para evitar que "pule" no momento de entrar com os dados
       Scanner scan = new Scanner (System.in);
       Scanner scanString = new Scanner(System.in);
       
       //variáveis de entrada de dados do usuário
       int menu;
       int ano;
       String titulo;
       String genero;
       double vFinal;
       double vInicial;
       
        do{
            exibirMenu(); //metodo de exibir menu (static)
            menu = scan.nextInt(); //resposta a qual item do menu foi selecionado
            switch (menu){ 
                case 1: 
                    System.out.println("CADASTRAR FILME");
                    Filme filme = new Filme(); //instancia o objeto filme
                    System.out.println("Digite o titulo do filme"); //preenche os atributos do objeto filme (linhas 27 a 34)
                    filme.setTitulo(scan.next());
                    System.out.println("Digite o ano de lançamento");
                    filme.setAno(scan.nextInt());
                    System.out.println("Digite o gênero");
                    filme.setGenero(scan.next());
                    System.out.println("Digite o preço");
                    filme.setPreco(scan.nextDouble());
                    Acervo.adicionar(filme); //passa o objeto filme preenchido como parâmetro do método adicionar, criado na classe Acervo
                    break; 
                case 2: 
                    System.out.println("ALTERAR TÍTULO DO FILME"); 
                    if(Acervo.listaPreenchida()){ //acessa o método que verifica se a lista está preenchida, retornando true para preenchida e false para vazia
                        System.out.println("Digite o titulo"); 
                        titulo = scanString.nextLine(); //usuário informa qual título deseja alterar
                        if(Acervo.alterar(titulo)) //o if aciona o método alterar, que retorna true se o titulo for encontrado e alterado
                            System.out.println("Título alterado"); //mensagem informando que a alteração foi feita
                            else 
                            System.out.println("Filme não encontrado"); //se o método retornar false significa que o filme não foi encontrado
                        }
                    else System.out.println("Acervo vazio!"); 
                    break;
                case 3: 
                    System.out.println("REMOVOR FILME"); //Exclusão realizada pelo título do filme
                    System.out.println("Digite o titulo"); 
                    titulo = scanString.nextLine(); //Usuário informa qual título deseja excluir
                    if(Acervo.listaPreenchida()){ 
                        if(Acervo.remover(titulo)) //o if aciona o método remover, que retorna true se o titulo for encontrado e removido
                            System.out.println("Filme removido"); //mensagem informando que a remoção foi feita
                            else 
                            System.out.println("Filme não encontrado"); //se o método retornar false significa que o filme não foi encontrado
                        }
                    else System.out.println("Acervo vazio!"); 
                    break;
                case 4:
                    System.out.println("LISTAR ACERVO");
                    if(Acervo.listaPreenchida()) //acessa o método que verifica se a lista está preenchida
                        Acervo.listar(); //se a lista estiver preenchida aciona o método listar(), na classe Acervo.
                        else System.out.println("Acervo vazio!"); //se a lista estiver vazia, apresenta essa informação ao usuário. 
                    break;
                 case 5: 
                     if(Acervo.listaPreenchida()){
                     System.out.println("LISTAR POR GENERO E APRESENTAR QUANTIDADE");
                     System.out.println("Digite o genero");
                     genero = scanString.nextLine();
                     Acervo.listar(genero);
                     System.out.println("Total: " + Acervo.qtdItens(genero));}
                     else 
                        System.out.println("Acervo vazio!");
                    break;
                case 6:
                    if(Acervo.listaPreenchida()){
                        System.out.println("LISTAR POR INTERVALO DE VALOR E APRESENTAR QUANTIDADE");
                        System.out.println("Digite o valor inicial:");
                        vInicial = scan.nextDouble();
                        System.out.println("Digite o valor final:");
                        vFinal = scan.nextDouble();
                        Acervo.listar(vInicial, vFinal);
                        System.out.println("Total: " + Acervo.qtdItens(vInicial, vFinal));}
                     else 
                        System.out.println("Acervo vazio!"); 
                    break;
                case 7: 
                    if(Acervo.listaPreenchida()){
                        System.out.println("LISTAR POR ANO E APRESENTAR QUANTIDADE");
                        System.out.println("Digite o ano");
                        ano = scan.nextInt();
                        Acervo.listar(ano);
                        System.out.println("Total: " + Acervo.qtdItens(ano));}
                     else 
                        System.out.println("Acervo vazio!"); 
                    break;
                case 8: 
                    if(Acervo.listaPreenchida()){
                    System.out.println("CALCULAR TOTAL DO ACERVO");
                    //Saiba mais sobre String.formati: https://www.javatpoint.com/java-string-format
                    System.out.println("Total: " + String.format ("R$ %.2f\n", Acervo.calcularTotalAcervo()));}
                    else 
                        System.out.println("Acervo vazio!"); 
                    break;
                case 9:
                    if(Acervo.listaPreenchida()){
                        Acervo.limparLista();
                        System.out.println("Lista limpa!");
                    }
                    else 
                        System.out.println("Acervo vazio, não há itens para limpar!"); 
                    break;
                 case 0: 
                    System.out.println("Menu encerrado");
                    break;
                default:  
                    System.out.println("Opcao inválida");
            }
        }while(menu>=0 && menu<=9);
}

static void exibirMenu(){
    System.out.println("MENU");
    System.out.println("Escolha a opção desejada: ");
    System.out.println("1. Cadastrar");
    System.out.println("2. Editar");
    System.out.println("3. Remover");
    System.out.println("4. Listar");
    System.out.println("5. Listar por genero");
    System.out.println("6. Listar por faixa de preço");
    System.out.println("7. Listar por ano");
    System.out.println("8. Calcular o total do acervo");
    System.out.println("9. Limpar lista");
    System.out.println("0. Sair");
}

}