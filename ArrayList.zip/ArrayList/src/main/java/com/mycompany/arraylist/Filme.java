
package com.mycompany.arraylist;
public class Filme {
    private String titulo;
    private int ano;
    private String genero;
    private double preco;


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
   
    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }
    
     public void imprimirFilme(){
        System.out.println("Titulo: " + getTitulo());
        System.out.println("Ano: " + getAno());
        System.out.println("Genero: " + getGenero());
        System.out.println("Preço: " + getPreco());
    }
    
}
