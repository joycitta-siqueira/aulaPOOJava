
package com.mycompany.arraylist;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Acervo {//classe para a lista de filmes, nosso Acervo
    
    private static final List<Filme> listaFilmes = new ArrayList<>(); //cria e instancia a lista

    public static List<Filme> getListaFilmes() { //método get, apenas retorna a lista
        return listaFilmes;
    }
    
    public static void adicionar(Filme f){ 
        listaFilmes.add(f); //.add método do ArrayList para adicionar objeto
    }
     
    public static boolean remover (String titulo){
        for (Filme f: listaFilmes){ 
            if(f.getTitulo().equalsIgnoreCase(titulo)){ //equalIgnoreCase - compara duas strings ignorando maiusculo e minúsculo
                listaFilmes.remove(f);
                return true;
            }  
        }
        return false;
    }
  
     public static boolean alterar(String titulo) { 
        Scanner scanString = new Scanner(System.in);
        String novoTitulo;
        for (Filme f: listaFilmes) {
            if (f.getTitulo().equalsIgnoreCase(titulo)) {
                System.out.println("Digite o novo título: ");
                novoTitulo = scanString.nextLine();
                f.setTitulo(novoTitulo);
                return true;
            }
        }
      return false;
    }
     
   
  /*EXEMPLO USANDO SIZE, GET E O FOR CONVENCIOANAL
    public static boolean alterar(String titulo) { 
        Scanner scanString = new Scanner(System.in);
        String novoTitulo;
        for (int i = 0; i <listaFilmes.size(); i++) {
            if (listaFilmes.get(i).getTitulo().equalsIgnoreCase(titulo)) {
                novoTitulo = scanString.nextLine();
                listaFilmes.get(i).setTitulo(novoTitulo);
                return true;
            }
        }
      return false;
    }
    */
    
    //4 métodos listar, com assinatura diferentes:  Sobrecarga de métodos
    public static void listar(){
        int i = 1;
        for (Filme f: listaFilmes){
            System.out.println("FILME N. " + (i++));
            f.imprimirFilme();
        }
    }
    
    public static void listar (String genero){
        for (Filme f: listaFilmes){
            if (f.getGenero().equalsIgnoreCase(genero))
               f.imprimirFilme();
        }
      }
    
    public static void listar(double vInicial, double vFinal){
        for (Filme f: listaFilmes){
            if (f.getPreco() >= vInicial && f.getPreco()<=vFinal)
                f.imprimirFilme();   
        }
    }
    
    public static void listar(int ano) {
        for (Filme f: listaFilmes){
            if(f.getAno()==ano)
                f.imprimirFilme();
        }
    }
    
    // outro exemplo de sobrecarga de métodos
    public static int qtdItens (String genero){
        int qtd = 0;
        for (Filme f: listaFilmes){
            if (f.getGenero().equalsIgnoreCase(genero))
                qtd++;
        }
        return qtd;
        }
    
    public static int qtdItens (double vInicial, double vFinal){
        int qtd = 0;
        for (Filme f: listaFilmes){
            if(f.getPreco() >= vInicial && f.getPreco() <= vFinal)
                qtd++;
        }
        return qtd; 
    }
    
    public static int qtdItens(int ano) {
            int cont = 0;
            for (Filme f: listaFilmes){
                if(f.getAno()==ano)
                    cont++;
            }
            return cont;
    }
    
    public static double calcularTotalAcervo(){
        double total = 0;
        for (Filme f: listaFilmes){
            total =+ f.getPreco();
        }
    return total;
    }
    
    public static boolean listaPreenchida(){
         /*verifica se a lista não está vazia, lembrando que:
          ! é o operador logico
         isEmpty() retorna um booelan, ou seja, true para lista vazia e false para lista preenchida
         */
        return !listaFilmes.isEmpty();
    }   
    
    public static void limparLista(){
        listaFilmes.clear();
    }
    
    
}