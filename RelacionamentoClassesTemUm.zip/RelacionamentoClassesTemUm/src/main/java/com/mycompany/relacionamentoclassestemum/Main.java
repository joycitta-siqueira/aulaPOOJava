package com.mycompany.relacionamentoclassestemum;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        
        Scanner ler = new Scanner (System.in);
        //Instanciar todos os objetos
        Contato c = new Contato();
        Endereco e = new Endereco();
        Telefone t = new Telefone();
        
        //Solicitação de dados ao usuário
        System.out.println("Digite o nome:");
        c.setNome(ler.nextLine());//Nome é atributo de Contato, por isso, c
        
        //Passando dados de endereço como parâmetro, direto no código
        System.out.println("Digite seu cep, rua, cidade e estado"); //Estes atributos estão na classe Endereco, por isso, e
        e.setNomeRua("Rua A");
        e.setNumero("10");
        e.setComplemento("Sem complemento");
        e.setCep("73368-865");
        e.setCidade("Planaltina");
        e.setEstado("DF");
     
        //Depois de preenchido o objeto endereço (e), é preciso "setar" no atribulo endereço, da classe Contato
        c.setEndereco(e);
        
        //Passando dados de telefone como parâmetro, direto no código
        System.out.println("Digite seu tipo, ddd e numero"); //Estes atributos estão na classe Telefone, por isso, t
        t.setTipo("Celular");
        t.setDdd("61");
        t.setNumero("99689-4785");
        
        //Depois de preenchido o objeto telefone (t), é preciso "setar" no atribulo telefone, da classe Contato
        c.setTel(t);
        
        //Médodo imprimir, implementada na classe Contato
        c.imprimir();
    }
    
}
