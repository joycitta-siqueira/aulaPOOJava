
package com.mycompany.relacionamentoclassestemum;

public class Contato {
    private String nome;
    private Endereco endereco; //endereço, do tipo Endereco (classe criada pelo programador)
    private Telefone tel; //tel, do tipo Telefone (classe criada pelo programador)

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Telefone getTel() {
        return tel;
    }

    public void setTel(Telefone tel) {
        this.tel = tel;
    }

    //Método para imprimir contato
    public void imprimir (){
        System.out.println("---- CONTATO ----");
        System.out.println("Nome: " +this.nome);
        System.out.println("Endereço: " +endereco.getNomeRua() + " " + endereco.getNumero() + " " + endereco.getComplemento() + " " + endereco.getCep() +" " +endereco.getCidade() +" " +endereco.getEstado());
        System.out.println("Telefone: " + tel.getTipo() + " - (" + tel.getDdd() + ") "+ tel.getNumero());
}   
}