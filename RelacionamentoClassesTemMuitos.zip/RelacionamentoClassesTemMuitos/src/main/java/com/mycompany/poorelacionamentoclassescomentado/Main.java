package com.mycompany.poorelacionamentoclassescomentado;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
      Scanner scan = new Scanner (System.in);
      AgendaContatos pessoa = new AgendaContatos();
      Telefone[] telefones = new Telefone[2];//Declarando vetor de 2 posições
      Endereco end = new Endereco();
      
        System.out.println("Digite o nome do contato:");
        pessoa.setNome(scan.nextLine());
        
        System.out.println("Digite o nome da rua:");
        end.setRua(scan.nextLine());
        
        System.out.println("Digite a cidade:");
        end.setCidade(scan.nextLine());
        
        System.out.println("Digite o estado:");
        end.setEstado(scan.nextLine());
        
        for (int i=0; i<2;i++){ 
            Telefone t = new Telefone(); //instanciando objeto telefone, para depois de preenchido, ser inserido no vetor
            System.out.println("Digite o tipo do telefone:");
            t.setTipo(scan.next());

            System.out.println("Digite o DDD:");
            t.setDdd(scan.next());

            System.out.println("Digite o telefone:");
            t.setNumero(scan.next());
            
            telefones[i] = t; //inserindo objeto preenchido no vetor
        }
        
        pessoa.setTelefones(telefones);
        pessoa.setEndereco(end);
        pessoa.imprimirContato();
    }
    
}
