package com.mycompany.poorelacionamentoclassescomentado;

public class AgendaContatos {
    private String nome;
    private Endereco endereco;
    private Telefone[] telefones; //declarando o atributo telefones como vetor

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    public Telefone[] getTelefones() {
        return telefones;
    }

    public void setTelefones(Telefone[] telefones) {
        this.telefones = telefones;
    }
    
    public void imprimirContato (){
        System.out.println("Nome: " + this.nome);
        System.out.println("----- Telefone -----");
        for (int i=0;i<2;i++){ //por ser vetor, é preciso do comando de repetição
            System.out.println("Telefone: " + telefones[i].getTipo() + " - (" + telefones[i].getDdd() + ") "+ telefones[i].getNumero());
        }
        System.out.println("-----  Endereco ----- ");
        System.out.println("Endereço: " +endereco.getRua() + " " + endereco.getCidade() + " " +endereco.getEstado());
    }
    
}


        
