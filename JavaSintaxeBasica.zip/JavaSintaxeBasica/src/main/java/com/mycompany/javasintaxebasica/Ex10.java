package com.mycompany.javasintaxebasica;
import java.util.Scanner;
public class Ex10 {
public static void main(String[] args) {

Scanner scan = new Scanner(System.in);

System.out.println("Digite sua nota:");

double nota = scan.nextDouble();

if (nota <= 30)
System.out.println("Nota muito baixa");
else if (nota < 70) 
System.out.println("Possivel recuperar");
else if (nota < 80)
System.out.println("Aprovado");
else System.out.println("Parabens"); 	
}
}

