package com.mycompany.javasintaxebasica;
public class Ex02 {
    public static void main(String[] args) { //passar o parâmetro na execução "java Ex02 Joyce", por exemplo.
	System.out.println("Primeiro programa do(a) " + args[0]); //por ser um vetor, é possível passar vários parâmetros
	System.out.println("Aula on-line!");
}
}
