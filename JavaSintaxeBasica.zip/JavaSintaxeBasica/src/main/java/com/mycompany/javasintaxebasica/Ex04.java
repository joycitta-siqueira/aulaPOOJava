package com.mycompany.javasintaxebasica;
public class Ex04 {
public static void main(String[] args) {
/* 
Tipos primitivos:
booleanos (boolean - true ou false);
numéricos (byte - 8bits,  short - 16 bits, int - 32 bits, long - 64 bits e char(tabela ascII))
string
ponto flutuante (float - 32 bits e double - 64 bits - aceitam notação científica )
Literais: hexadecimais, octais e binarios
\ para caracteres especiais
*/	
boolean vBoolean = false;
byte vByte = 10;
short vShort = 100;
int vInt = 10000;
long vLong = 100000;
char vChar = 'S';
char vChar2 = 112;
String vString = "texto";
float vFloat = 4.5f;
double vDouble = 5.6;
double vDouble2 = 1.234e2; /* 1.234 x 10^2 */

System.out.println("Valor de boolean: " + vBoolean);
System.out.println("Valor de byte:  " + vByte);
System.out.println("Valor de shor:  " + vShort);
System.out.println("Valor de int:  " + vInt);
System.out.println("Valor de long:  " + vLong);
System.out.println("Valor de char:  " + vChar);
System.out.println("Valor de char:  " + vChar2);
System.out.println("Valor de string:  " + vString);
System.out.println("Valor de float:  " + vFloat);
System.out.println("Valor de double:  " + vDouble);
System.out.println("Valor de double:  " + vDouble2);
}
}

