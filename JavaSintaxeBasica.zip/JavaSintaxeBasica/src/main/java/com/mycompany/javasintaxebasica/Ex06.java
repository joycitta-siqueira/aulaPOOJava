package com.mycompany.javasintaxebasica;
import java.util.Scanner;

public class Ex06 {
public static void main(String[] args) {

Scanner scan = new Scanner (System.in);

int operacoes = 50;
operacoes = operacoes + 1;
System.out.println ("Soma " + operacoes);
operacoes = operacoes - 1;
System.out.println ("Subtracao " + operacoes);
operacoes = operacoes * 1;
System.out.println ("Multiplicacao " + operacoes);
operacoes = operacoes / 1;
System.out.println ("Divisao " + operacoes);
operacoes = operacoes % 1;
System.out.println ("Modulo " + operacoes);


operacoes = 1;
System.out.println ("op++:" + operacoes++);
System.out.println ("op++:" + operacoes);

operacoes = 1;
operacoes = operacoes + 1;
System.out.println ("op+1:" + operacoes);

operacoes = 1;
operacoes += 1;
operacoes -= 1;
operacoes *= 1;
operacoes /= 1;
System.out.println ("op+=:" + operacoes);

operacoes = 1;
System.out.println ("++op:" + ++operacoes);

operacoes = 1;
System.out.println ("op--:" + operacoes--);
System.out.println ("op--:" + operacoes);

operacoes = 1;
System.out.println ("--op:" + --operacoes);

}
}

