package com.mycompany.javasintaxebasica;
public class Ex03 {
    public static void main(String[] args) {
	int a, b, c;	
	a = 1;
	b = 2;
	c = a + b;
	System.out.println("Resultado " + c);
}
}
/*
* Palavras reservadas: http://www.linhadecodigo.com.br/artigo/83/as-52-palavras-reservadas-do-java.aspx.
* Convenção de nomenclatura: UpperCamelCase e * lowerCamelCase
* variável: primeira letra - a-z A-Z _ &
* as próximas: a-z A-Z _ & 0-9
* não se usa o &
* Case Sensitive
*/
