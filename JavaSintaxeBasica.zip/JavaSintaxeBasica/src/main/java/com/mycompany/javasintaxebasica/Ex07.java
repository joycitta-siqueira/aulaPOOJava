package com.mycompany.javasintaxebasica;
import java.util.Scanner;

public class Ex07 {
    public static void main(String[] args) {

    Scanner scan = new Scanner (System.in);

    System.out.println("Informe dois valores");
    int n1 = scan.nextInt();
    int n2 = scan.nextInt();

    System.out.println("São iguais?" + (n1==n2));
    System.out.println("São diferentes?" + (n1!=n2));
    System.out.println("O primeiro, eh maior que o segundo? " + (n1>n2));
    System.out.println("O primeiro, eh menor que o segundo? " + (n1<n2));
    System.out.println("O primeiro, eh maior ou igual que o segundo? " + (n1>=n2));
    System.out.println("O primeiro, eh menor ou igual que o segundo? " + (n1<=n2));
}
}

