package com.mycompany.javasintaxebasica;
import java.util.Scanner;
public class Ex11 {
public static void main(String[] args) {

Scanner scan = new Scanner(System.in);

System.out.println("Digite os valores de a, b, c e d");

int a = scan.nextInt();
int b = scan.nextInt();
int c = scan.nextInt();
int d = scan.nextInt();

if(b>c&&d>a&&((c+d)>(a+b))&&c>0 && d>0 &&a%2==0)
    System.out.println("Valores aceitos: " + a + " " + b + " " + c + " " + d);
    else System.out.println("Valores nao aceitos: " + a + " " + b + " " + c + " " + d);
}
}

