package com.mycompany.javasintaxebasica;

public class Ex08 {
    public static void main(String[] args) {
        int a = 5, b = 6;
        boolean resultAnd, resultOr, resultNao, resultXor;

        resultAnd = (a == 5) && (b == 6);
        resultOr = (a == 5) || (b == 6);
        resultNao = !(a == 5);
        resultXor = (a == 5) ^ (b == 6);

        System.out.println("Resultado Logico And:" + resultAnd);
        System.out.println("Resultado Logico Or:" + resultOr);
        System.out.println("Resultado Logico Nao:" + resultNao);
        System.out.println("Resultado Logico Xor:" + resultXor);

        boolean c=true, d=false;
        System.out.println(c && d);
        System.out.println(c || d);
        System.out.println(!d);
        System.out.println(!c);
        System.out.println(c ^ d);


    }
}

