package com.mycompany.javasintaxebasica;
public class Ex01 {
    public static void main(String[] args) {
	System.out.println("Primeiro programa!");
	System.out.println("Teste sem ln!");
}
}

