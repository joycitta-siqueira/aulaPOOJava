package com.mycompany.javasintaxebasica;
import java.util.Scanner; //importa a biblioteca Scanner

public class Ex05 {
public static void main(String[] args) {

Scanner scan = new Scanner (System.in); // instanciar objeto

System.out.println ("Digite seu nome completo:");
String nome = scan.nextLine(); //lê a linha inteira

System.out.println ("Digite seu nome: ");
String primeiroNome = scan.next(); //lê a primeira palavra

System.out.println ("Digite sua idade: ");
int idade = scan.nextInt(); //lê valor inteiro

System.out.println ("Digite seu salario: ");
double salario = scan.nextDouble(); //lê ponto flutuante
//para entrar com número real no cmd, usar virgula ou invés de ponto. Ex: 9,8

System.out.println ("Nome completo: " + nome);
System.out.println ("Primeiro nome: " + primeiroNome);
System.out.println ("Idade: " + idade);
System.out.println ("Salario: " + salario);

//OUTRO EXEMPLO
System.out.println("Digite seu primeiro nome, idade, salario, quantidade de dependentes e se declara imposto de renda");
//separado por espaço
String primeiroNome2 = scan.next();
int idade2 = scan.nextInt(); 
double salario2 = scan.nextDouble();
byte dep = scan.nextByte();
boolean ir = scan.nextBoolean();

System.out.println ("Primeiro nome: " + primeiroNome2);
System.out.println ("Idade: " + idade2);
System.out.println ("Salario: " + salario2);
System.out.println ("N de dependentes: " + dep);
System.out.println ("Declara imposto? " + ir);
}
}
